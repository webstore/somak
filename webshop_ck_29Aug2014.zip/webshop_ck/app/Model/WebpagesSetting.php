<?php
 

/**
 * Description of Webpagesetting
 *
 * @author somak
 */
App::uses('AppModel', 'Model');

class WebpagesSetting extends AppModel {  
    
    public $validate = array(
         
        'header_text' => array(
            'notEmpty' => array(
                'rule' => array('notEmpty')
            ),
        ),
        
        'footer_text' => array(
            'notEmpty' => array(
                'rule' => array('notEmpty')
            ),
        ),
         
    );
    
    
    
    public function uploadLogo($filePointer) {
        
        $returnLogoName ='';
        
        $tmp_name = $_FILES[$filePointer]["tmp_name"];
        
        $original_name  = $_FILES[$filePointer]["name"];
        
        $fileInfo = (pathinfo($_FILES[$filePointer]["name"]));

        if (isset($fileInfo['extension'])) {

            $extenstion = $fileInfo['extension'];
            
            $searchArr = array(',', ' ', '.');
            
            $replaceArr = array('', '_', '_');

            $name = str_replace($searchArr, $replaceArr, $original_name);

            $refinedName = WWW_ROOT . 'uploads' . DS . "site_logo.$extenstion";

            if (move_uploaded_file($tmp_name, $refinedName)) {
                
                $returnLogoName = "site_logo.$extenstion";
            }
        }
        
        return $returnLogoName;
    }
    
}
