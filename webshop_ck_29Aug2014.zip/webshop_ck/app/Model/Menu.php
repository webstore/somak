<?php

App::uses('AppModel', 'Model');

class Menu extends AppModel {

    public $postData;
    
    public $validate = array(
         
        'menu_name' => array(
            'page_labelRule-1' => array(
                'rule'    => array('notEmpty'),
                'message' => 'Empty value not allowed',
             ),
            
            'page_labelRule-2' => array(
                'rule'    => 'isUnique',
                'message' => 'Already this value added',
                'on' => 'create', // here
            ),
            
        ),
        
        'safe_name' => array(
            'page_labelRule-1' => array(
                'rule'    => array('notEmpty'),
                'message' => 'Empty value not allowed',
             ),
            
            'page_labelRule-2' => array(
                'rule'    => 'isUnique',
                'message' => 'Already has this record',
                'on' => 'create', // here
            ),
        ),
         
    );

    
    
    
    
}
