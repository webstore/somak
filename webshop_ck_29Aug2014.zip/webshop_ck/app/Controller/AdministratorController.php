<?php

/**
 * Description of AdminastratorController
 *
 * @author somak
 */
App::uses('AppController', 'Controller');

class AdministratorController extends AppController {

    //put your code here
    public $modelAdmin, $modelWebPage;
    public $loginUser;

    //public $helpers = array('Html','Form','Session');

    public function beforeFilter() {
        parent::beforeFilter();
        $this->Auth->allow('login');
        /*$this->Auth->authenticate = array(
            'all' => array('userModel' => 'Admin'),
            'Form',
            'Basic',
        );*/
        
        $this->Auth->loginRedirect = array('controller' => 'administrator', 'action' => 'login');
        $this->Auth->logoutRedirect = array('controller' => 'administrator', 'action' => 'login');
        $this->Auth->authError = array('Did you really think you are allowed to see that?');
        $this->layout = 'admin_layout';
        $this->initModels();
    }

    public function initModels() {

        $this->loadModel('Admin');
        $this->loadModel('Webpage');
        $this->modelAdmin = $this->Admin;
        $this->modelWebPage = $this->Webpage;
    }

    /** Login page * */
    public function login() {

        if ($this->request->is('post')) {

            if ($this->Auth->login()) {
                $this->loginUser = AuthComponent::user();
                $this->redirect($this->Auth->redirect());
            } else {
                $this->Session->setFlash(__('Invalid username or password'));
            }
        }
    }

    /** Logout page * */
    public function logout() {
        $this->redirect($this->Auth->logout());
    }

    public function index() {
    }

    public function pages() {
        $webpageDropDown = $this->modelWebPage->fetchWebPagesDropDown();
        $this->set('webpageDropDown', $webpageDropDown);

        if ($this->request->is('post')) {

            $this->modelWebPage->postData = $this->request->data;

            switch ($this->request->data['Webpage']['webpage_action']) {

                case 'add':
                    $lastInsertedId = $this->modelWebPage->addpage();

                    if ($lastInsertedId != false)
                        $this->Session->setFlash(__('Record has been created'));

                    break;

                case 'update':

                    if ($this->modelWebPage->updatePage())
                        $this->Session->setFlash(__('Record updated successfully'));
                    else
                        $this->Session->setFlash(__('Unable to update records'));

                    break;

                case 'delete':
                    $this->modelWebPage->delete($this->request->data('Webpage.id'));
                    $this->Session->setFlash(__('Record deleted successfully'));

                    break;
            }

            $this->redirect('pages#info');
        }
    }

    public function ajaxloadpage() {
        if ($this->request->is('post')) {
            $pageRs = $this->modelWebPage->fetchWebPageById($this->request->data['webpage_id']);
            if (isset($pageRs['Webpage']) && !empty($pageRs['Webpage']))
                echo json_encode($pageRs['Webpage']);
        }
        exit();
    }

    
    public function siteheader() {

        $this->loadModel('WebpagesSetting');

        $settingRS = $this->WebpagesSetting->find('first');

        if (empty($this->data)) {
            $this->data = $settingRS;
        }

        if ($this->request->is('post')) {

            switch ($this->request->data['WebpagesSetting']['page_action']) {
                case 'header':

                    if ($this->WebpagesSetting->save($this->request->data))
                        $this->Session->setFlash(__('Record has been saved'));
                    else
                        $this->Session->setFlash(__('Unable to save'));

                    break;
            }
            $this->redirect('siteheader');
        }
    }

    
    public function ajaxlogoUploader() {
        $this->loadModel('WebpagesSetting');
        $returnLogoName = '';
        if (isset($_FILES["file"]["tmp_name"]) && !empty($_FILES["file"]["tmp_name"])) {
            $returnLogoName = $this->WebpagesSetting->uploadLogo('file');
        }
        echo $returnLogoName;
        exit();
    }
    
    public $string;
    
    public function sitefooter() {
                
        /*if(isset($_POST['serialised_menu']) && !empty($_POST['serialised_menu'])){
        
            echo "<pre>";
            $out=json_decode($_POST['serialised_menu']);
            foreach($out as $key) {
                
                $key = (array) $key;
                
                //echo "<br>".$key['id'].' - parent = 0';
                //$this->string[] = array($key['id']=>'0');
                $this->string[$key['id']] = '0';
                $this->getChild($key, $level=" ----".$key['id'].'----');
            }
            print_r($this->string);
            die;
        }
        */
        $this->loadModel('WebpagesSetting');
        $settingRS = $this->WebpagesSetting->find('first');

        if (empty($this->data)) {
            $this->data = $settingRS;
        }
        
        
        if ($this->request->is('post')) {

            switch ($this->request->data['WebpagesSetting']['page_action']) {
                case 'footer':

                    if ($this->WebpagesSetting->save($this->request->data))
                        $this->Session->setFlash(__('Record has been saved'));
                    else
                        $this->Session->setFlash(__('Unable to save'));

                    break;
            }
            $this->redirect('sitefooter');
            exit();
        }
    }
    
    
    public function getChild($arrayList, $level='&nbsp;&nbsp;---'){
        $mapstringNew ='';
        if(isset($arrayList['children'])){
            foreach($arrayList['children'] as $child){
                
                $child = (array) $child;
                //echo "<br>".$child['id']. ' - parent = '.$arrayList['id'];
                //$this->string .="<br>".$child['id']. ' - parent = '.$arrayList['id'];
                //$this->string[] = array($child['id']=>$arrayList['id']);
                $this->string[$child['id']] = $arrayList['id'];
                
                $level.=$child['id'].'----';
                
                $this->getChild($child, $level);
                
                return $mapstringNew ;
            }
        }
    }
    
    
    public function sitemenu(){
        $this->loadModel('Menu');
        
        $menuOptions = $this->Menu->find('list', array('fields'=>array('id','menu_name')));
        
        $this->set('menuOptions', $menuOptions);

        if ($this->request->is('post')) {
            switch ($this->request->data['Menu']['page_action']) {
                case 'menu_add':
                    if ($this->Menu->save($this->request->data)) {
                        $this->Session->setFlash(__('Record has been saved'));
                        $this->redirect('sitemenu');
                    }
                    else
                        $this->Session->setFlash(__('Unable to save'));
                break;
                
                
                case 'menu_delete':
                    if ($this->Menu->delete($this->request->data('Menu.id'))) {
                        $this->Session->setFlash(__('Menu deleted successfully'));
                        $this->redirect('sitemenu');
                    }
                    else
                      $this->Session->setFlash(__('Unable to delete'));
                break;
            }
            
            //$this->redirect('sitemenu');
            
        }
    }
    

}
